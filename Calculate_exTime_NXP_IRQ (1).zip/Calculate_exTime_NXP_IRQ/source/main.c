#include "LPC54018.h"
#include "board.h"
#include "pin_mux.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "fsl_pint.h"
#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

void delayTimer(uint32_t elapsedTimer);

void delayTimer(uint32_t elapsedTimer)
{
	uint32_t i;
	
	for(i=0; i<elapsedTimer; i++)
	{
		__asm("nop");
	}
}

int main(void)
{
	unsigned int start_time, stop_time, cycle_count;
	
	/* Board pin, clock, debug console init */
	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
	BOARD_InitPins();
	BOARD_BootClockPLL180M();
	BOARD_InitDebugConsole();
	
	/* Define the init structure for the output LED pin*/
	gpio_pin_config_t led_config = {
		kGPIO_DigitalOutput,
		0,
	};

	PINT_Type pint; // Base address of the PINT peripheral 
	pint_pin_int_t intr = kPINT_PinInt0;
	pint_pin_enable_t enable = kPINT_PinIntEnableRiseEdge;
	pint_cb_t callback;
	uint32_t ret;
	
	SysTick->CTRL = 0; // Disables SysTick
	SysTick->LOAD = 0xFFFFFFFF; // Sets the Reload value to maximum
	SysTick->VAL = 0; // Clears the current value to 0
	SysTick->CTRL = 0x5; // Enables the SysTick, uses the processor clock
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_Init(&pint); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptConfig(&pint, intr, enable, callback);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptGetConfig(&pint, intr, &enable, &callback);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptClrStatus(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptGetStatus(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	ret = PINT_PinInterruptGetStatus(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	ret = PINT_PinInterruptGetStatusAll(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptClrStatus(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_EnableCallback(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_EnableCallbackByIndex(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_DisableCallback(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_DisableCallbackByIndex(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptClrFallFlag(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptClrFallFlagAll(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptGetFallFlag(&pint, intr);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_PinInterruptGetFallFlagAll(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	PINT_Deinit(&pint);
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
}