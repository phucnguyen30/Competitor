#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_pint.h"

#include "fsl_common.h"
#include "fsl_inputmux.h"
#include "pin_mux.h"


// DEFINITIONS
#define PINT_PIN_INT0_SRC kINPUTMUX_GpioPort0Pin4ToPintsel

// FUNCTION PROTOTYPES
void pint_intr_callback(pint_pin_int_t pintr, uint32_t pmatch_status);

// VARIABLES


//void pint_intr_callback(pint_pin_int_t pintr, uint32_t pmatch_status)
{
    ;
}

void main(void)
{  
    unsigned int start_time, stop_time, cycle_count;
    
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // Sets the Reload value to maximum
    SysTick->VAL = 0; // Clears the current value to 0
    SysTick->CTRL = 0x5; // Enables the SysTick, uses the processor clock
    
    // Board pin, clock, debug console init
    // attach 12 MHz clock to FLEXCOMM0 (debug console)
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM0);

    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();

    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    INPUTMUX_Init(INPUTMUX);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    INPUTMUX_AttachSignal(INPUTMUX, kPINT_PinInt0, PINT_PIN_INT0_SRC);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    INPUTMUX_Deinit(INPUTMUX);
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_Init(PINT);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_PinInterruptConfig(PINT, kPINT_PinInt0, kPINT_PinIntEnableRiseEdge, pint_intr_callback);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_EnableCallback(PINT);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_DisableCallback(PINT);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_PinInterruptClrStatus(PINT, kPINT_PinInt0);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
    start_time = SysTick->VAL; // Obtains the start time
    PINT_Deinit(PINT);
    stop_time = SysTick->VAL; // Obtains the stop time
    cycle_count = start_time – stop_time; // Calculates the time taken
    
    while (1)
    {
        __WFI();
    }
}