#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"

#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

void delayTimer(uint32_t elapsedTimer);

uint32_t tPoint1,tPoint2,tPoint3,tDiff;
volatile unsigned int start_time, stop_time,end_time[10]={0};
void delayTimer(uint32_t elapsedTimer)
{
	uint32_t i;
	
	for(i=0; i<elapsedTimer; i++)
	{
		__asm("nop");
	}
}

int main(void)
{
	/* Board pin, clock, debug console init */
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();
	
	/* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {
        kGPIO_DigitalOutput,
        0,
    };
	
	//CTimerInit
	ctimer_config_t config;
	ctimer_match_config_t matchConfig;

	/*CTimer use APB bus clock as Timer tick, set the APB bus clock as 12MHz internal FRO */
	CLOCK_AttachClk(kFRO12M_to_ASYNC_APB);
	
	CTIMER_GetDefaultConfig(&config);

	CTIMER_Init(CTIMER3, &config);

	matchConfig.enableCounterReset = true;
	matchConfig.enableCounterStop = false;
	matchConfig.matchValue = 0xFFFFFFFF;
	matchConfig.outControl = kCTIMER_Output_NoAction;
	matchConfig.outPinInitState = true;
	matchConfig.enableInterrupt = false;
	
	CTIMER_SetupMatch(CTIMER3, kCTIMER_Match_3, &matchConfig);
	CTIMER_StartTimer(CTIMER3);
	
	// measure GPIO_PortInit
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	GPIO_PortInit(GPIO, APP_BOARD_TEST_LED_PORT);
        stop_time = SysTick->VAL;
        end_time[0] = start_time - stop_time;
	
	// measure GPIO_PinInit
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	GPIO_PinInit(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN, &led_config);
        stop_time = SysTick->VAL;
        end_time[1] = start_time - stop_time;
	
	// measure GPIO_PinWrite
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	GPIO_PinWrite(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN, 1);
        stop_time = SysTick->VAL;
        end_time[2] = start_time - stop_time;
	
	CTIMER_Reset(CTIMER3);
	
	// measure GPIO_PinRead
	uint32_t ret;
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	ret = GPIO_PinRead(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN);
        stop_time = SysTick->VAL;
        end_time[3] = start_time - stop_time;
	
	// measure GPIO_PortSet
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	GPIO_PortSet(GPIO, APP_BOARD_TEST_LED_PORT, 1);
        stop_time = SysTick->VAL;
        end_time[4] = start_time - stop_time;
        
        // measure GPIO_PinRead
	
	SysTick->CTRL = 0;//adfdsf
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL != 0);
        start_time = SysTick->VAL;
	ret = GPIO_PortRead(GPIO, APP_BOARD_TEST_LED_PORT);
        stop_time = SysTick->VAL;
        end_time[5] = start_time - stop_time;

	while (1);
}