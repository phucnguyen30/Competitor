#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"

#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

void delayTimer(uint32_t elapsedTimer);

uint32_t tPoint1,tPoint2,tPoint3,tDiff;

void delayTimer(uint32_t elapsedTimer)
{
	uint32_t i;
	
	for(i=0; i<elapsedTimer; i++)
	{
		__asm("nop");
	}
}

int main(void)
{
	/* Board pin, clock, debug console init */
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();
	
	/* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {
        kGPIO_DigitalOutput,
        0,
    };
	
	//CTimerInit
	ctimer_config_t config;
	ctimer_match_config_t matchConfig;

	/*CTimer use APB bus clock as Timer tick, set the APB bus clock as 12MHz internal FRO */
	CLOCK_AttachClk(kFRO12M_to_ASYNC_APB);
	
	CTIMER_GetDefaultConfig(&config);

	CTIMER_Init(CTIMER3, &config);

	matchConfig.enableCounterReset = true;
	matchConfig.enableCounterStop = false;
	matchConfig.matchValue = 0xFFFFFFFF;
	matchConfig.outControl = kCTIMER_Output_NoAction;
	matchConfig.outPinInitState = true;
	matchConfig.enableInterrupt = false;
	
	CTIMER_SetupMatch(CTIMER3, kCTIMER_Match_3, &matchConfig);
	CTIMER_StartTimer(CTIMER3);
	
	// measure GPIO_PortInit
	tPoint1=CTIMER_GetTimerCountValue(CTIMER3);
	GPIO_PortInit(GPIO, APP_BOARD_TEST_LED_PORT);
	tPoint2=CTIMER_GetTimerCountValue(CTIMER3);
	tDiff=tPoint2-tPoint1;
	CTIMER_Reset(CTIMER3);
	
	// measure GPIO_PinInit
	tPoint1=CTIMER_GetTimerCountValue(CTIMER3);
	GPIO_PinInit(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN, &led_config);
	tPoint2=CTIMER_GetTimerCountValue(CTIMER3);
	tDiff=tPoint2-tPoint1;
	CTIMER_Reset(CTIMER3);
	
	// measure GPIO_PinWrite
	tPoint1=CTIMER_GetTimerCountValue(CTIMER3);
	GPIO_PinWrite(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN, 1);
	tPoint2=CTIMER_GetTimerCountValue(CTIMER3);
	tDiff=tPoint2-tPoint1;
	
	CTIMER_Reset(CTIMER3);
	
	// measure GPIO_PinRead
	uint32_t ret;
	tPoint1=CTIMER_GetTimerCountValue(CTIMER3);
	ret = GPIO_PinRead(GPIO, APP_BOARD_TEST_LED_PORT, APP_BOARD_TEST_LED_PIN);
	tPoint2=CTIMER_GetTimerCountValue(CTIMER3);
	tDiff=tPoint2-tPoint1;
	CTIMER_Reset(CTIMER3);
	
	// measure GPIO_PortSet
	tPoint1=CTIMER_GetTimerCountValue(CTIMER3);
	GPIO_PortSet(GPIO, APP_BOARD_TEST_LED_PORT, 1);
	tPoint2=CTIMER_GetTimerCountValue(CTIMER3);
	tDiff=tPoint2-tPoint1;
	CTIMER_Reset(CTIMER3);


	while (1);
}