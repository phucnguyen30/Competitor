/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_ctimer.h"
#include "LPC54018.h"
#include "pin_mux.h"
#include <stdbool.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define CTIMER          CTIMER3         /* Timer 3 */
#define CTIMER_MAT0_OUT kCTIMER_Match_0 /* Match output 0 */
#define CTIMER_MAT1_OUT kCTIMER_Match_1 /* Match output 1 */
#define CTIMER_CLK_FREQ CLOCK_GetFreq(kCLOCK_AsyncApbClk)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void ctimer_match0_callback(uint32_t flags);
void ctimer_match1_callback(uint32_t flags);

/* Array of function pointers for callback for each channel */
ctimer_callback_t ctimer_callback_table[] = {
    ctimer_match0_callback, ctimer_match1_callback, NULL, NULL, NULL, NULL, NULL, NULL};

/*******************************************************************************
 * Variables
 ******************************************************************************/
/* Match Configuration for Channel 0 */
static ctimer_match_config_t matchConfig0;
/* Match Configuration for Channel 1 */
static ctimer_match_config_t matchConfig1;

/*******************************************************************************
 * Code
 ******************************************************************************/

void ctimer_match1_callback(uint32_t flags)
{
    static uint32_t count            = 0;
    static uint32_t matchUpdateCount = 8;

    if (++count > matchUpdateCount)
    {
        count = 0;
        matchConfig1.matchValue >>= 1;
        matchUpdateCount <<= 1;
        if (matchUpdateCount == (1 << 8))
        {
            matchUpdateCount        = 8;
            matchConfig1.matchValue = CTIMER_CLK_FREQ / 2;
        }
        CTIMER_SetupMatch(CTIMER, CTIMER_MAT1_OUT, &matchConfig1);
    }
}

void ctimer_match0_callback(uint32_t flags)
{
    static uint32_t count            = 0;
    static uint32_t matchUpdateCount = 8;

    if (++count > matchUpdateCount)
    {
        count = 0;
        matchConfig0.matchValue >>= 1;
        matchUpdateCount <<= 1;
        if (matchUpdateCount == (1 << 8))
        {
            matchUpdateCount        = 8;
            matchConfig0.matchValue = CTIMER_CLK_FREQ / 2;
        }
        CTIMER_SetupMatch(CTIMER, CTIMER_MAT0_OUT, &matchConfig0);
    }
}

void delay(void)
{
    volatile uint32_t i = 0;
    for (i = 0; i < 800000; ++i)
    {
        __asm("NOP"); /* delay */
    }
}
/*!
 * @brief Main function
 */
    volatile unsigned int cnt1 = 0;
    volatile unsigned int cnt2 = 0;
    volatile unsigned int end_time[10] = {0};
int main(void)
{
    ctimer_config_t config;

    /* Init hardware*/
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* Enable the asynchronous bridge */
    SYSCON->ASYNCAPBCTRL = 1;
    //SYSCON->SYSTCKCAL=
    /* Use 12 MHz clock for some of the Ctimers */
    CLOCK_AttachClk(kFRO12M_to_ASYNC_APB);

    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();

    PRINTF("CTimer match example to toggle the output. \r\n");
    PRINTF("This example uses interrupt to change the match period. \r\n");
    CTIMER_GetDefaultConfig(&config);
    
    /* Measure time to do function Init */
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_Init(CTIMER, &config);
    cnt2 = SysTick->VAL;
    end_time[0]= cnt1-cnt2;
    /* Configuration 0 */
    matchConfig0.enableCounterReset = true;
    matchConfig0.enableCounterStop  = false;
    matchConfig0.matchValue         = CTIMER_CLK_FREQ / 2;
    matchConfig0.outControl         = kCTIMER_Output_Toggle;
    matchConfig0.outPinInitState    = false;
    matchConfig0.enableInterrupt    = false;

    /* Configuration 1 */
    matchConfig1.enableCounterReset = true;
    matchConfig1.enableCounterStop  = true;
    matchConfig1.matchValue         = CTIMER_CLK_FREQ / 2;
    matchConfig1.outControl         = kCTIMER_Output_Toggle;
    matchConfig1.outPinInitState    = true;
    matchConfig1.enableInterrupt    = true;
    
    
    
    /* Measure time to do function CTIMER_RegisterCallBack */
    cnt1 = 0;
    cnt2 = 0;
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_RegisterCallBack(CTIMER, &ctimer_callback_table[0], kCTIMER_MultipleCallback);
    cnt2 = SysTick->VAL;
    end_time[1]= cnt1-cnt2;
    /* Measure time to do function SetupMatch */
    cnt1 = 0;
    cnt2 = 0;
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_SetupMatch(CTIMER, CTIMER_MAT0_OUT, &matchConfig0);
    cnt2 = SysTick->VAL;
    end_time[2]= cnt1-cnt2;
    
    CTIMER_SetupMatch(CTIMER, CTIMER_MAT1_OUT, &matchConfig1);
    /* Measure time to do function Start */
    cnt1 = 0;
    cnt2 = 0;
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_StartTimer(CTIMER);
    cnt2 = SysTick->VAL;
    end_time[3]= cnt1-cnt2;
    
    cnt1 = 0;
    cnt2 = 0;
    /* Measure time to do function reset */
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_Reset(CTIMER);    
    cnt2 = SysTick->VAL;
    end_time[4]= cnt1-cnt2;

    cnt1 = 0;
    cnt2 = 0;
    /* Measure time to do function stop */
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_StopTimer(CTIMER);    
    cnt2 = SysTick->VAL;
    end_time[5]= cnt1-cnt2;

    cnt1 = 0;
    cnt2 = 0;
    /* Measure time to do function deinitialization*/
    SysTick->CTRL = 0; // Disables SysTick
    SysTick->LOAD = 0xFFFFFFFF; // one second delay relaod value
    SysTick->CTRL = 5 ; // enable counter and select system bus clock 
    SysTick->VAL  = 0;
    while(SysTick->VAL != 0);
    cnt1 = SysTick->VAL;
    CTIMER_Deinit(CTIMER);    
    cnt2 = SysTick->VAL;
    end_time[6]= cnt1-cnt2;

    while (1)
    {
      
    }
    
}
