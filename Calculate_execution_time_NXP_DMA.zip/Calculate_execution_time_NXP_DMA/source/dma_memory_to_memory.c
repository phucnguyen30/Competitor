/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_dma.h"

#include "fsl_ctimer.h"
#include "pin_mux.h"
#include <stdbool.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/

#define BUFF_LENGTH 4U

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
// DMA0 is defined in LPC54018.h
dma_handle_t g_DMA_Handle;
volatile bool g_Transfer_Done                                                           = false;
DMA_ALLOCATE_DATA_TRANSFER_BUFFER(uint32_t s_srcBuffer[BUFF_LENGTH], sizeof(uint32_t))  = {0x01, 0x02, 0x03, 0x04};
DMA_ALLOCATE_DATA_TRANSFER_BUFFER(uint32_t s_destBuffer[BUFF_LENGTH], sizeof(uint32_t)) = {0x00, 0x00, 0x00, 0x00};

volatile unsigned int end_time[20] = {0};
unsigned int start_time, stop_time;
/*******************************************************************************
 * Code
 ******************************************************************************/

/* User callback function for DMA transfer. */
void DMA_Callback(dma_handle_t *handle, void *param, bool transferDone, uint32_t tcds)
{
    if (transferDone)
    {
        g_Transfer_Done = true;
    }
}

/*!
 * @brief Main function
 */
int main(void)
{
    uint32_t i = 0;
    dma_channel_config_t transferConfig;

    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM0);

    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();
    /* Print source buffer */
    PRINTF("DMA memory to memory transfer example begin.\r\n\r\n");
    PRINTF("Destination Buffer:\r\n");
    for (i = 0; i < BUFF_LENGTH; i++)
    {
        PRINTF("%d\t", s_destBuffer[i]);
    }
    /* Configure DMA one shot transfer */
    /*
     * userConfig.enableRoundRobinArbitration = false;
     * userConfig.enableHaltOnError = true;
     * userConfig.enableContinuousLinkMode = false;
     * userConfig.enableDebugMode = false;
     */
     
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_Init(DMA0);
    stop_time = SysTick->VAL;
    end_time[0] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_CreateHandle(&g_DMA_Handle, DMA0, 0);
    stop_time = SysTick->VAL;
    end_time[1] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_EnableChannel(DMA0, 0);
    stop_time = SysTick->VAL;
    end_time[2] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_SetCallback(&g_DMA_Handle, DMA_Callback, NULL);
    stop_time = SysTick->VAL;
    end_time[3] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_IRQHandle(DMA0);
    stop_time = SysTick->VAL;
    end_time[4] = start_time - stop_time;
    
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_PrepareChannelTransfer(&transferConfig, s_srcBuffer, &s_destBuffer[0],
                               DMA_CHANNEL_XFER(false, false, true, false, 4, kDMA_AddressInterleave1xWidth,
                                                kDMA_AddressInterleave1xWidth, 16),
                               kDMA_MemoryToMemory, NULL, NULL);
    stop_time = SysTick->VAL;
    end_time[5] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_SubmitChannelTransfer(&g_DMA_Handle, &transferConfig);
    stop_time = SysTick->VAL;
    end_time[6] = start_time - stop_time;
     
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_StartTransfer(&g_DMA_Handle);
    stop_time = SysTick->VAL;
    end_time[7] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_DisableChannel(DMA0, 0);
    stop_time = SysTick->VAL;
    end_time[8] = start_time - stop_time;
     
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_AbortTransfer(&g_DMA_Handle);
    stop_time = SysTick->VAL;
    end_time[9] = start_time - stop_time;
    
    SysTick->CTRL=0;
    SysTick->LOAD = 0xFFFFFFFF;
    SysTick->CTRL=0x5;
    SysTick->VAL = 0;
    start_time = SysTick->VAL;
    DMA_Deinit(DMA0);
    stop_time = SysTick->VAL;
    end_time[10] = start_time - stop_time;
    
    
    /* Wait for DMA transfer finish */
    while (g_Transfer_Done != true)
    {
    }
    /* Print destination buffer */
    PRINTF("\r\n\r\nDMA memory to memory transfer example finish.\r\n\r\n");
    PRINTF("Destination Buffer:\r\n");
    for (i = 0; i < BUFF_LENGTH; i++)
    {
        PRINTF("%d\t", s_destBuffer[i]);
    }
    
    
    
    while (1)
    {
    }
}
