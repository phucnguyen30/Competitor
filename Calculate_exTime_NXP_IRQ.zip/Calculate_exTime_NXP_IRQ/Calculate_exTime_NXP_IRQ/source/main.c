#include "LPC54018.h"
#include "board.h"
#include "pin_mux.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"

#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

void delayTimer(uint32_t elapsedTimer);

void delayTimer(uint32_t elapsedTimer)
{
    uint32_t i;
    
    for(i=0; i<elapsedTimer; i++)
    {
        __asm("nop");
    }
}
volatile unsigned int start_time, stop_time, cycle_count[10];
int main(void)
{
    
    /* Board pin, clock, debug console init */
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();
    
    /* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {
        kGPIO_DigitalOutput,
        0,
    };

    IRQn_Type irq = GINT0_IRQn;
    
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        while(SysTick->VAL!=0);
        start_time = SysTick->VAL;          
        EnableIRQ(irq);            
        stop_time = SysTick->VAL;
        cycle_count[0] = start_time - stop_time;
        

          
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        while(SysTick->VAL!=0);
        start_time = SysTick->VAL;            
        DisableIRQ(irq);
        stop_time = SysTick->VAL;
        cycle_count[1] = start_time - stop_time;
    
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        while(SysTick->VAL!=0);
        start_time = SysTick->VAL;
        EnableDeepSleepIRQ(irq);
        stop_time = SysTick->VAL;
        cycle_count[2] = start_time - stop_time;
    
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        while(SysTick->VAL!=0);
        start_time = SysTick->VAL;
        DisableDeepSleepIRQ(irq);
        stop_time = SysTick->VAL;
        cycle_count[3] = start_time - stop_time;
    
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL!=0);
        start_time = SysTick->VAL;
        EnableGlobalIRQ(irq);
        stop_time = SysTick->VAL;
        cycle_count[4] = start_time - stop_time;
          
        uint32_t ret;
        SysTick->CTRL = 0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL = 0x5;
        SysTick->VAL = 0;
        //while(SysTick->VAL!=0);
        start_time = SysTick->VAL;
        ret = DisableGlobalIRQ();        
        stop_time = SysTick->VAL;
        cycle_count[5] = start_time - stop_time;
         
        while(1)
        {}

}