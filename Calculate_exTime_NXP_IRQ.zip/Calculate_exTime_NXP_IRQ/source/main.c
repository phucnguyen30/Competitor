#include "LPC54018.h"
#include "board.h"
#include "pin_mux.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"

#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

void delayTimer(uint32_t elapsedTimer);

void delayTimer(uint32_t elapsedTimer)
{
	uint32_t i;
	
	for(i=0; i<elapsedTimer; i++)
	{
		__asm("nop");
	}
}

int main(void)
{
	unsigned int start_time, stop_time, cycle_count;
	
	/* Board pin, clock, debug console init */
	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
	BOARD_InitPins();
	BOARD_BootClockPLL180M();
	BOARD_InitDebugConsole();
	
	/* Define the init structure for the output LED pin*/
	gpio_pin_config_t led_config = {
		kGPIO_DigitalOutput,
		0,
	};

	IRQn_Type irq = GINT0_IRQn;
	
	SysTick->CTRL = 0; // Disables SysTick
	SysTick->LOAD = 0xFFFFFFFF; // Sets the Reload value to maximum
	SysTick->VAL = 0; // Clears the current value to 0
	SysTick->CTRL = 0x5; // Enables the SysTick, uses the processor clock
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	EnableIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	DisableIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	EnableDeepSleepIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	DisableDeepSleepIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	EnableGlobalIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken
	
	uint32_t ret;
	while(SysTick->VAL != 0); // Waits until the SysTick is reloaded
	start_time = SysTick->VAL; // Obtains the start time
	ret = DisableGlobalIRQ(irq); // Executes the function to be measured
	stop_time = SysTick->VAL; // Obtains the stop time
	cycle_count = start_time – stop_time; // Calculates the time taken

}