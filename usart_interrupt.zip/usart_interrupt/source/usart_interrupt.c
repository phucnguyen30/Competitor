#include "board.h"
#include "fsl_debug_console.h"

#include "board.h"


#include "pin_mux.h"
#include <stdbool.h>
#include "core_cm4.h"

//#include "fsl_ctimer.h"

#define APP_BOARD_TEST_LED_PORT 3U
#define APP_BOARD_TEST_LED_PIN  13U

#define USE 	(1)
#define NOT_USE (0)



/* Select peripheral module */
#define PERIPHERAL_MODULE (USE)

/* Define API function name */
 #define API_FUNCTION_1 USART_Init
 #define API_FUNCTION_3  USART_GetInstance
#define API_FUNCTION_4 USART_Deinit
#define API_FUNCTION_5 USART_GetDefaultConfig
#define API_FUNCTION_6 USART_SetBaudRate
#define API_FUNCTION_7 USART_Enable32kMode
#define API_FUNCTION_8 USART_WriteBlocking
#define API_FUNCTION_9 USART_ReadBlocking
#define API_FUNCTION_10 USART_TransferCreateHandle
#define API_FUNCTION_11 USART_TransferSendNonBlocking
#define API_FUNCTION_12 USART_TransferStartRingBuffer
#define API_FUNCTION_13 USART_TransferStopRingBuffer
#define API_FUNCTION_14 USART_TransferGetRxRingBufferLength
#define API_FUNCTION_15 USART_TransferAbortSend
#define API_FUNCTION_16 USART_TransferGetSendCount
#define API_FUNCTION_17 USART_TransferReceiveNonBlocking
#define API_FUNCTION_18 USART_TransferAbortReceive
#define API_FUNCTION_19 USART_TransferGetReceiveCount
#define API_FUNCTION_20 USART_TransferHandleIRQ



#if (PERIPHERAL_MODULE == USE)
/* Include header files of peripheral module */
#include "fsl_common.h"
#include "fsl_usart.h"
#else
/* Define dummy function */
void API_FUNCTION_1(void){ }
//void API_FUNCTION_2(void){ }
void API_FUNCTION_3(void){ }
void API_FUNCTION_4(void){ }
void API_FUNCTION_5(void){ }
void API_FUNCTION_6(void){ }
void API_FUNCTION_7(void){ }
void API_FUNCTION_8(void){ }
void API_FUNCTION_9(void){ }
void API_FUNCTION_10(void){ }
void API_FUNCTION_11(void){ }
void API_FUNCTION_12(void){ }
void API_FUNCTION_13(void){ }
void API_FUNCTION_14(void){ }
void API_FUNCTION_15(void){ }
void API_FUNCTION_16(void){ }
void API_FUNCTION_17(void){ }
void API_FUNCTION_18(void){ }
void API_FUNCTION_19(void){ }
void API_FUNCTION_20(void){ }
#endif

uint32_t tPoint1,tPoint2,tPoint3,tDiff;

void delayTimer(uint32_t elapsedTimer)
{
	uint32_t i;
	
	for(i=0; i<elapsedTimer; i++)
	{
		__asm("nop");
	}
}

void delayTimer(uint32_t elapsedTimer);
void main(void);
volatile uint32_t addr;

#define DEMO_USART            USART0
#define DEMO_USART_CLK_FREQ   CLOCK_GetFlexCommClkFreq(0U)
#define DEMO_USART_IRQHandler FLEXCOMM0_IRQHandler
#define DEMO_USART_IRQn       FLEXCOMM0_IRQn
void main(void)
{
	addr = (uint32_t)API_FUNCTION_1;
//	addr = (uint32_t)API_FUNCTION_2;
        addr = (uint32_t)API_FUNCTION_3;
        addr = (uint32_t)API_FUNCTION_4;
        addr = (uint32_t)API_FUNCTION_5;
        addr = (uint32_t)API_FUNCTION_6;
        addr = (uint32_t)API_FUNCTION_7;
        addr = (uint32_t)API_FUNCTION_8;
        addr = (uint32_t)API_FUNCTION_9;
        addr = (uint32_t)API_FUNCTION_10;
        addr = (uint32_t)API_FUNCTION_11;
        addr = (uint32_t)API_FUNCTION_12;
        addr = (uint32_t)API_FUNCTION_13;
        addr = (uint32_t)API_FUNCTION_14;
        addr = (uint32_t)API_FUNCTION_15;
        addr = (uint32_t)API_FUNCTION_16;
        addr = (uint32_t)API_FUNCTION_17;
        addr = (uint32_t)API_FUNCTION_18;
        addr = (uint32_t)API_FUNCTION_19;
        addr = (uint32_t)API_FUNCTION_20;

	
	/* Board pin, clock, debug console init */
	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
	BOARD_InitPins();
	BOARD_BootClockPLL180M();
	BOARD_InitDebugConsole();
	
	/*
     * config.baudRate_Bps = 115200U;
     * config.parityMode = kUSART_ParityDisabled;
     * config.stopBitCount = kUSART_OneStopBit;
     * config.loopback = false;
     * config.enableTxFifo = false;
     * config.enableRxFifo = false;
     */
   usart_config_t config;
    USART_GetDefaultConfig(&config);
    config.baudRate_Bps = BOARD_DEBUG_UART_BAUDRATE;
    config.enableTx     = true;
    config.enableRx     = true;
    
    usart_handle_t handle;
    usart_transfer_t xfer;
    size_t receivedBytes;
        
	unsigned int start_time, stop_time, end_time[2];
	
        SysTick->CTRL=0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL=0x5;
        SysTick->VAL = 0;
	
        start_time = SysTick->VAL;
        USART_Init(DEMO_USART, &config, DEMO_USART_CLK_FREQ);
        stop_time = SysTick->VAL;
        end_time[0] = start_time - stop_time;
        
        SysTick->CTRL=0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL=0x5;
        SysTick->VAL = 0;
        
        start_time = SysTick->VAL;
       USART_TransferSendNonBlocking(DEMO_USART, &handle, &xfer);
        stop_time = SysTick->VAL;
        end_time[1] = start_time - stop_time;

        SysTick->CTRL=0;
        SysTick->LOAD = 0xFFFFFFFF;
        SysTick->CTRL=0x5;
        SysTick->VAL = 0;	
        
        start_time = SysTick->VAL;
        USART_TransferReceiveNonBlocking(DEMO_USART,&handle,&xfer,&receivedBytes);
        stop_time = SysTick->VAL;
        end_time[2] = start_time - stop_time;

	while(1);
}