
/*******************************************************************************
 * Includes
 ******************************************************************************/
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define USE     (1)
#define NOT_USE (0)  /* BSP only */

/* Select peripheral module. */
#define PERIPHERAL_MODULE (USE)
/* Define the API function name. */
#define API_FUNCTION_1  INPUTMUX_Init
#define API_FUNCTION_2  INPUTMUX_AttachSignal
#define API_FUNCTION_3  BOARD_InitPins
#define API_FUNCTION_4  INPUTMUX_Deinit
//#define API_FUNCTION_5  INPUTMUX_EnableSignal
#define API_FUNCTION_6  IOCON_PinMuxSet
#include <stdint.h>
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
#if (PERIPHERAL_MODULE == USE)
/* Include header files of peripheral module. */
//#include "fsl_wwdt.h"
#include "fsl_inputmux.h"
//#include "fsl_inputmux_connections.h"
#include "fsl_iocon.h"
#include "fsl_common.h"
#include "pin_mux.h"
#else
/* When using only BSP, define the dummy function. */
void API_FUNCTION_1(void){ }
void API_FUNCTION_2(void){ }
void API_FUNCTION_3(void){ }
void API_FUNCTION_4(void){ }
void API_FUNCTION_5(void){ }
void API_FUNCTION_6(void){ }
#endif
/*******************************************************************************
 * Variables
 ******************************************************************************/
void main(void);
volatile uint32_t addr;
/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief Main function
 */
void main(void)
{  
    /* Get the address of API function. */
    addr = (uint32_t)API_FUNCTION_1;
    addr = (uint32_t)API_FUNCTION_2;
    addr = (uint32_t)API_FUNCTION_3;
    addr = (uint32_t)API_FUNCTION_4;
    //addr = (uint32_t)API_FUNCTION_5;
    addr = (uint32_t)API_FUNCTION_6;

    while(1);
}
