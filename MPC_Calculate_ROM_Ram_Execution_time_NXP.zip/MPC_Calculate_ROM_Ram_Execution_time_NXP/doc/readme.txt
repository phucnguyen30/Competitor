Overview
========
The GPIO Blink project is a demonstration program that uses the KSDK software to manipulate the general-purpose
outputs. The example use LEDs demonstrates GPIO API for port and pin manipulation (init, toggle).



Toolchain supported
===================
- IAR embedded Workbench  8.50.1
- MCUXpresso  11.2.0
- GCC ARM Embedded  9.2.1
- Keil MDK  5.30

Hardware requirements
=====================
- Micro USB cable
- Click board
- Personal Computer

Board settings
==============
No special settings are required.

Prepare the Demo
================
1.  Connect a micro USB cable between the host PC and the LPC-Link USB port (J8) on the target board.
2.  Download the program to the target board.
3.  Launch the debugger in your IDE to begin running the demo.

Running the demo
================
Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.

No serial terminal when the demo program is executed.
LED D1 is blinking.
Customization options
=====================

